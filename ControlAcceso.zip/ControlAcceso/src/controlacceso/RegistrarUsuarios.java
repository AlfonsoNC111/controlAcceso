package controlacceso;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RegistrarUsuarios extends javax.swing.JFrame {

    //Inicializamos variables y sus valores
    String titulos[] = {"id usuario", "Nombre", "Numero de Puerta", "Puesto", "Contraseña", "Tipo de Usuario", "Modelo del Dispositivo", "Marca del Dispositivo", "Número de Serie del Dispositivo"};
    String fila[] = new String[9];
    DefaultTableModel modelo;
    Connection con = null;
    Statement stmt = null;
    String var, var2;

    public RegistrarUsuarios() {
        initComponents();
        // Configuración de la ventana
        this.setTitle("Registro de Usuarios");
        this.setLocation(400, 200);
        this.setResizable(false);
        ImageIcon icono = new ImageIcon("C:\\Users\\HP\\Documents\\NetBeansProjects\\pruebaLeds\\src\\Imagenes\\agros.png");
        this.setIconImage(icono.getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        txt_id = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        lb_nombre = new javax.swing.JLabel();
        lb_puerta = new javax.swing.JLabel();
        txt_puerta = new javax.swing.JTextField();
        txt_puesto = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_pass = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cmb_tipoUsuario = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txt_modelo = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_marca = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_numSerie = new javax.swing.JTextField();
        btn_actualizar = new javax.swing.JButton();
        btn_guardar = new javax.swing.JButton();
        Fondo = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        consultaDeUsuarios = new javax.swing.JMenu();
        consultaGeneral = new javax.swing.JMenuItem();
        consultarUsuario = new javax.swing.JMenuItem();
        MenuPrincipal = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setText("ID:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 60, -1));

        txt_id.setEditable(false);
        txt_id.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(txt_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 60, -1));

        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        txt_nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nombreKeyTyped(evt);
            }
        });
        getContentPane().add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 180, -1));

        lb_nombre.setText("Nombre completo:");
        getContentPane().add(lb_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 130, -1));

        lb_puerta.setText("Número de Puerta:");
        getContentPane().add(lb_puerta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 130, -1));

        txt_puerta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_puertaKeyTyped(evt);
            }
        });
        getContentPane().add(txt_puerta, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 60, -1));
        getContentPane().add(txt_puesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 100, -1));

        jLabel1.setText("Puesto del usuario:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 110, -1));

        jLabel2.setText("Contraseña:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 90, -1));

        txt_pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_passKeyTyped(evt);
            }
        });
        getContentPane().add(txt_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 160, -1));

        jLabel3.setText("Tipo de Cuenta:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 130, -1));

        cmb_tipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona una opción...", "Administrador", "Usuario" }));
        getContentPane().add(cmb_tipoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 200, -1));

        jLabel5.setText("Modelo del dispositivo:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));
        getContentPane().add(txt_modelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 180, -1));

        jLabel6.setText("Marca del dispositivo:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, -1));
        getContentPane().add(txt_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 130, -1));

        jLabel7.setText("Número de Serie del dispositivo:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));
        getContentPane().add(txt_numSerie, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 160, -1));

        btn_actualizar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_actualizar.setText("ACTUALIZAR");
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, -1, -1));

        btn_guardar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_guardar.setText("GUARDAR");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, -1, -1));

        Fondo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/agros.png"))); // NOI18N
        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 350));

        consultaDeUsuarios.setText("Menú");
        consultaDeUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultaDeUsuariosActionPerformed(evt);
            }
        });

        consultaGeneral.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        consultaGeneral.setText("Tabla General de Usuarios");
        consultaGeneral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultaGeneralActionPerformed(evt);
            }
        });
        consultaDeUsuarios.add(consultaGeneral);

        consultarUsuario.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK));
        consultarUsuario.setText("Información del Usuario");
        consultarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultarUsuarioActionPerformed(evt);
            }
        });
        consultaDeUsuarios.add(consultarUsuario);

        MenuPrincipal.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_MASK));
        MenuPrincipal.setText("Menú Principal");
        MenuPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuPrincipalActionPerformed(evt);
            }
        });
        consultaDeUsuarios.add(MenuPrincipal);

        jMenuBar1.add(consultaDeUsuarios);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Método Actualizar
    public void actualizar() {
        //variables de control de recuperación de datos 
        String cadena1, cadena2, cadena3, cadena4, cadena5, cadena6, cadena7, cadena8, cadena9;
        //Inicialización de variables de control
        cadena1 = txt_id.getText();
        cadena2 = txt_nombre.getText();
        cadena3 = txt_puerta.getText();
        cadena4 = txt_puesto.getText();
        cadena5 = txt_pass.getText();
        cadena6 = cmb_tipoUsuario.getSelectedItem().toString();
        cadena7 = txt_modelo.getText();
        cadena8 = txt_marca.getText();
        cadena9 = txt_numSerie.getText();

        //Condición de validación información en los campos
        if (txt_nombre.getText().equals("")) {
            //ventana de instrucción
            javax.swing.JOptionPane.showMessageDialog(this, "1.-Seleccione la opción Menú\n"
                    + "2.- Selecione la opción Consultar Usuario Específico\n"
                    + "3.- Ingrese el nombre completo del usuario\n"
                    + "4.- Actualice el dato deseado en el campo correspondiente",
                     "AVISO!", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else {
            //CONEXIÓN PARTICULAR A LA BASE DE DATOS
            try {
                String url = "jdbc:mysql://localhost:3306/controlacceso"; //NOMBRE DE LA BASE DE DATOS
                String usuario = "root"; //NOMBRE DE USUARIO EN MYSQL
                String contraseña = "123root"; //CONTRASEÑA DE MYSQL
                //IMPORTACIÓN DE CLASE ENLACE DE ENVIO DE DATOS
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                con = DriverManager.getConnection(url, usuario, contraseña);
                if (con != null) //MENSAJE VERIFICADOR EN CONSOLA
                {
                    System.out.println("Se ha establecido una conexión a la base de datos "
                            + "\n " + url);
                }
                stmt = con.createStatement();
                //ACTUALIZACIÓN DE DATOS
                stmt.executeUpdate("update ignore usuarios set id= '" + cadena1 + "' , nombre = '" + cadena2 + "',puerta = '" + cadena3 + "',puesto = '" + cadena4 + "', pass = '" + cadena5 + "', tipousuario = '" + cadena6 + "', modelo = '" + cadena7 + "', marca = '" + cadena8 + "', serie = '" + cadena9 + "'"
                        + " where id = '" + txt_id.getText() + "' || nombre = '" + txt_nombre.getText() + "' || puerta = '" + txt_puerta.getText() + "' || puesto = '" + txt_puesto.getText() + "' || pass = '" + txt_pass.getText() + "' || tipousuario = '" + cmb_tipoUsuario.getSelectedItem() + "' || modelo = '" + txt_modelo.getText() + "' || marca = '" + txt_marca.getText() + "' || serie = '" + txt_numSerie.getText() + "'");
                //MENSAJE ACTUALIZACIÓN DE DATOS
                System.out.println("Los valores han sido Actualizados");
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                //CIERRE DE CONEXION CON LA BASE DE DATOS
                if (con != null) {
                    try {
                        con.close();
                        stmt.close();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }
            }
            //MENSAJE PARA EL USUARIO
            javax.swing.JOptionPane.showMessageDialog(this, "Actualizado correctamente!", "AVISO!", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        }
        //LIMPIEZA DE CAMPOS
        this.txt_id.setText("");
        this.txt_nombre.setText("");
        this.txt_puerta.setText("");
        this.txt_puesto.setText("");
        this.txt_pass.setText("");
        this.txt_modelo.setText("");
        this.txt_marca.setText("");
        this.txt_numSerie.setText("");
    }

    // Metodo Consultar
    public void consulta() {
        //DECLARACIÓN DE VARIABLES
        String cap = "";
        ResultSet rs = null;
        var2 = var;
        //COSULTA A LA BASE DE DATOS
        String sql2 = "Select id, nombre, puerta, puesto, pass, tipousuario, modelo, marca,serie FROM usuarios where nombre = '" + var2 + "'";

        try {
            //CONEXIÓN PARTICULAR CON LA BASE DE DATOS
            String url = "jdbc:mysql://localhost:3306/controlacceso"; //NOMBRE DE LA BASE DE DATOS 
            String usuario = "root"; //USUARIO DE MYSQL
            String contraseña = "123root"; //CONTRASEÑA DE MYSQL

            // CLASE PARA EL ENVIO DE DATOS DE LA BASE DE DATOS
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            // VARIABLE DE CONTROL DE DATOS
            con = DriverManager.getConnection(url, usuario, contraseña);
            //CONDICIÓN DEL MANEJO DE DATOS
            if (con != null) //MENSAJE DE VERIFICACIÓN EN CONSOLA
            {
                System.out.println("Se ha establecido una conexión a la base de datos \n " + url);
            }
            //VARIABLES DE MANEJO DE LA BASE DE DATOS
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql2);
            //VARIABLE CONTADOR 
            int i = 1;
            //CONDICION DE BUSQUEDA
            while (rs.next()) {
                // VARIABLES DE CONTROL DE DATOS
                String id = rs.getString("id");
                String inom = rs.getString("nombre");
                String ipuerta = rs.getString("puerta");
                String ipuesto = rs.getString("puesto");
                String ipass = rs.getString("pass");
                String itipo = rs.getString("tipousuario");
                String imodelo = rs.getString("modelo");
                String imarca = rs.getString("marca");
                String inumero_serie = rs.getString("serie");
                System.out.println("Sitio Web " + (i++) + ":\n"
                        + id + "\n"
                        + inom + "\n"
                        + ipuerta + "\n"
                        + ipuesto + "\n"
                        + ipass + "\n"
                        + itipo + "\n"
                        + imodelo + "\n"
                        + imarca + "\n"
                        + inumero_serie + "\n\n");
                //ENVIO DE DATOS A LOS CAMPOS
                txt_id.setText(id);
                txt_nombre.setText(inom);
                txt_puerta.setText(ipuerta);
                txt_puesto.setText(ipuesto);
                txt_pass.setText(ipass);
                cmb_tipoUsuario.setSelectedItem(itipo);
                txt_modelo.setText(imodelo);
                txt_marca.setText(imarca);
                txt_numSerie.setText(inumero_serie);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            //DESCONEXION CON LA BASE DE DATOS
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                    ex.printStackTrace();
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                    ex.printStackTrace();
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                    ex.printStackTrace();
                }
            }
        }
    }

    private void consultaGeneralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultaGeneralActionPerformed
        //CAMBIO DE VENTANA A TABLA GENERAL DE USUARIOS
        this.dispose();
        consultaUsuarios cu = new consultaUsuarios();
        cu.setVisible(true);
    }//GEN-LAST:event_consultaGeneralActionPerformed

    private void consultarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultarUsuarioActionPerformed
        // OPCIÓN DE MENÚ Consultar INFORMACIÓN DE USUARIO
        //DECLARACIÓN DE VARIABLES
        String cap = "";
        ResultSet rs = null;
        //VENTANA DE REQUISICIÓN DE DATOS
        var = javax.swing.JOptionPane.showInputDialog(this, "Nombre del usuario", "Consulta usuario", javax.swing.JOptionPane.QUESTION_MESSAGE);
        //VARABLE DE CONSULTA DE LA BASE DE DATOS
        String sql = "SELECT* FROM  usuarios WHERE nombre = '" + var + "'";
        //CONDICION DE CANCELACIÓN
        if (var == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "La accion fue cancelada", "AVISO!", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        } else {
            //CONDICION DE CAMPO
            if (var.equals("")) {
                javax.swing.JOptionPane.showMessageDialog(this, "Favor de ingresar el nombre de usuario\nque desea consultar", "AVISO!", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            } else {
                try {
                    //CONEXION PARTICULAR CON LA BASE DE DATOS
                    String url = "jdbc:mysql://localhost:3306/controlacceso";
                    String usuario = "root";
                    String contraseña = "123root";
                    //CLASE PARA EL ENVIO DE DATOS DE LA BD
                    Class.forName("com.mysql.jdbc.Driver").newInstance();
                    //VARIABLE DE CONEXION DE DATOS
                    con = DriverManager.getConnection(url, usuario, contraseña);
                    if (con != null) {
                        System.out.println("Se ha establecido una conexión a la base de datos "
                                + "\n " + url);
                    }

                    stmt = con.createStatement();
                    rs = stmt.executeQuery(sql);

                    while (rs.next()) {
                        //VARIABLE DE VALIDACIÓN DE TIPO DE USUARIO
                        cap = rs.getString("tipousuario");
                        //CONDICIÓN DE TIPO DE USUARIO
                        if (cap.equals("Usuario") || cap.equals("Administrador")) {
                            consulta();
                        }
                    }   // fin del bucle While

                } catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
                } finally {
                    //DESCONEXIÓN CON LA BASE DE DATOS
                    if (con != null) {
                        try {
                            con.close();
                            stmt.close();
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }
                //CONDICIÓN SI EL USUARIO NO EXISTE
                if (!cap.equals("Usuario") && !cap.equals("Administrador")) {
                    //MENSAJE DE ERROR PARA EL USUARIO
                    javax.swing.JOptionPane.showMessageDialog(this, "El usuario no fue encontrado\n", "ERROR!", javax.swing.JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_consultarUsuarioActionPerformed

    private void MenuPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuPrincipalActionPerformed
        // CAMBIO DE VENTANA A MENU PRINCIPAL DEL ADMINISTRADOR
        this.dispose();
        Menu cu = new Menu();
        cu.setVisible(true);
    }//GEN-LAST:event_MenuPrincipalActionPerformed

    private void consultaDeUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultaDeUsuariosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_consultaDeUsuariosActionPerformed

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void txt_nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nombreKeyTyped
        //ACEPTACION DE SOLO CARACTERES ALFABÉTICOS Y ESPACIOS EN BLANCO
        char c = evt.getKeyChar();
        if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < ' ' || c > ' ')) {
            evt.consume();
        }
    }//GEN-LAST:event_txt_nombreKeyTyped

    private void txt_puertaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_puertaKeyTyped
        //ACEPTACION DE SOLO CARACTERES NUMÉRICOS
        char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_txt_puertaKeyTyped

    private void txt_passKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passKeyTyped
        //ACEPTACION DE SOLO CARACTERES NUMÉRICOS
        char c = evt.getKeyChar();
        if ((c < '0' || c > '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_txt_passKeyTyped

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        //METODO ACTUALIZAR
        actualizar();
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
        // DECLARACION DE VARIABLES
        String cadena1, cadena2, cadena3, cadena4, cadena5, cadena6, cadena7, cadena8;
        //VALORES DE LAS VARIABLES
        cadena1 = txt_nombre.getText();
        cadena2 = txt_puerta.getText();
        cadena3 = txt_puesto.getText();
        cadena4 = txt_pass.getText().toString();
        cadena5 = cmb_tipoUsuario.getSelectedItem().toString();
        cadena6 = txt_modelo.getText();
        cadena7 = txt_marca.getText();
        cadena8 = txt_numSerie.getText();
        // CONDICION DE LOS CAMPOS EN BLANCO
        if (txt_nombre.getText().equals("") || (txt_puerta.getText().equals("")) || (txt_puesto.getText().equals("")) || (txt_pass.getText().equals(""))
                || (cmb_tipoUsuario.getSelectedItem().equals("Selecciona una opción...")) || (txt_modelo.getText().equals("")) || (txt_marca.getText().equals("")) || (txt_numSerie.getText().equals(""))) {
            javax.swing.JOptionPane.showMessageDialog(this, "Debe llenar todos los campos \n", "ADVERTENCIA", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            txt_nombre.requestFocus();
        }else{
            try {
                //CONEXION PARTICULAR CON LA BASE DE DATOS
                String url = "jdbc:mysql://localhost:3306/controlacceso";//NOMBRE DE LA BASE DE DATOS
                String usuario = "root"; //USUARIO DE MYSQL
                String contraseña = "123root"; //CONTRASELA DE MYSQL
                //CLASE DE ENVIO DE DATOS DE LA BASE DE DATOS
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                //VARIABLE DE CONEXIÓN CON LA BASE DE DATOS
                con = DriverManager.getConnection(url,usuario,contraseña);
                
                //CONDICIÓN DE CONEXIÓN CON LA BD
                if (con != null) System.out.println("Se ha establecido una conexión a la base de datos " + 
                                                    "\n " + url ); 
                  stmt = con.createStatement();
                  stmt.executeUpdate("INSERT INTO usuarios VALUES('" + 0 + "','"+cadena1+"','"+cadena2+"','"+cadena3+"','"+cadena4+"','"+cadena5+"','"+cadena6+"','"+cadena7+"','"+cadena8+"')");
                  //MENSAJE DE VALIDACIÓN DE DATOS DE LA BD
                  System.out.println("Los valores han sido agregados a la base de datos ");

            } catch (InstantiationException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(RegistrarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            }
            finally {
                //CONDICION DE ERROR
                if (con != null) {
                    try {
                        con.close();
                        stmt.close();
                    } catch ( Exception e ) { 
                         System.out.println( e.getMessage());
                    }
                }
            }
            //MENSAJE EXITOSO PARA EL USUARIO
            javax.swing.JOptionPane.showMessageDialog(this,"Registro exitoso! \n","AVISO!",javax.swing.JOptionPane.INFORMATION_MESSAGE);
            }
        //LIMPIEZA DE CAMPOS
        this.txt_nombre.setText("");
        this.txt_puerta.setText("");
        this.txt_puesto.setText("");
        this.txt_pass.setText("");
        this.txt_modelo.setText("");
        this.txt_marca.setText("");
        this.txt_numSerie.setText("");
    }//GEN-LAST:event_btn_guardarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrarUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Fondo;
    private javax.swing.JMenuItem MenuPrincipal;
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JComboBox<String> cmb_tipoUsuario;
    private javax.swing.JMenu consultaDeUsuarios;
    private javax.swing.JMenuItem consultaGeneral;
    private javax.swing.JMenuItem consultarUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JLabel lb_nombre;
    private javax.swing.JLabel lb_puerta;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_marca;
    private javax.swing.JTextField txt_modelo;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_numSerie;
    private javax.swing.JTextField txt_pass;
    private javax.swing.JTextField txt_puerta;
    private javax.swing.JTextField txt_puesto;
    // End of variables declaration//GEN-END:variables
}
