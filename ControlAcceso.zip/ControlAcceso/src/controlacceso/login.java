package controlacceso;

import br.com.adilson.util.Extenso;
import br.com.adilson.util.PrinterMatrix;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import controlacceso.ConexionDB;
import controlacceso.Menu;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.print.PrinterJob;
import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttribute;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import panamahitek.Arduino.PanamaHitek_Arduino;

public class login extends javax.swing.JFrame {

    DefaultTableModel registros = new DefaultTableModel();
    ConexionDB cc = new ConexionDB();
    Connection con = cc.conexion();
    PanamaHitek_Arduino Arduino = new PanamaHitek_Arduino();
    Calendar fecha = new GregorianCalendar();
    String anho = Integer.toString(fecha.get(Calendar.YEAR));
    String mes = Integer.toString(fecha.get(Calendar.MONTH));
    String dia = Integer.toString(fecha.get(Calendar.DATE));
    String fechacompleta = anho + "-" + (mes + 1) + "-" + dia;
    String horas = Integer.toString(fecha.get(Calendar.HOUR_OF_DAY));
    String minutos = Integer.toString(fecha.get(Calendar.MINUTE));
    String horacompleta = horas + ":" + minutos;
    String ruta_destino = null;
    
    static String impresora = "EPSON L3210 Series";
    static String serial = "";
    static String grados = "0";

    public login() {
        initComponents();
        this.setTitle("LOGIN");
        this.setSize(850, 450);
        java.awt.Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Imagenes/agros.png"));
        this.setIconImage(img);
        this.setLocation(270, 180);
        String[] titulo = new String[]{"USUARIO", "FECHA", "HORA"};
        registros.setColumnIdentifiers(titulo);
        tabla_registros.setModel(registros);
        try {
            Arduino.arduinoTX("COM4", 9600);
        } catch (Exception ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_iniciar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        txt_usuario = new javax.swing.JTextField();
        txt_pass = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        txt_puerta = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_registros = new javax.swing.JTable();
        btn_imprimir = new javax.swing.JButton();
        txt_lineas = new javax.swing.JTextField();
        txt_columnas = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lb_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/agros.png"))); // NOI18N
        lb_logo.setMaximumSize(new java.awt.Dimension(100, 100));
        lb_logo.setMinimumSize(new java.awt.Dimension(100, 100));
        getContentPane().add(lb_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 240, 240));

        jLabel1.setText("USUARIO:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, -1, -1));

        jLabel2.setText("CONTRASEÑA:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));

        btn_iniciar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_iniciar.setText("INICIAR SESIÓN");
        btn_iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_iniciarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_iniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 360, -1, -1));

        btn_cancelar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_cancelar.setText("CERRAR");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 360, -1, -1));

        txt_usuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_usuarioKeyTyped(evt);
            }
        });
        getContentPane().add(txt_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 220, -1));

        txt_pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_passKeyTyped(evt);
            }
        });
        getContentPane().add(txt_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 190, -1));

        jLabel3.setText("NÚMERO DE PUERTA:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, -1, -1));

        txt_puerta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_puertaKeyTyped(evt);
            }
        });
        getContentPane().add(txt_puerta, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 320, 70, -1));

        tabla_registros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla_registros);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 380, 290));

        btn_imprimir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_imprimir.setText("IMPRIMIR TICKET");
        btn_imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_imprimirActionPerformed(evt);
            }
        });
        getContentPane().add(btn_imprimir, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 350, -1, -1));

        txt_lineas.setText("9");
        getContentPane().add(txt_lineas, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 350, 50, -1));

        txt_columnas.setText("32");
        getContentPane().add(txt_columnas, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 350, 60, -1));

        jLabel4.setText("Altura:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 330, -1, -1));

        jLabel5.setText("Ancho:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        // Cerrar programa
        System.exit(0);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_iniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_iniciarActionPerformed
        // Iniciar sesión
        PDF();
        ValidarUsuario();
    }//GEN-LAST:event_btn_iniciarActionPerformed

    private void txt_usuarioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_usuarioKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        if((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' '))evt.consume();
    }//GEN-LAST:event_txt_usuarioKeyTyped

    private void txt_puertaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_puertaKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
    }//GEN-LAST:event_txt_puertaKeyTyped

    private void txt_passKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        if((c<'0' || c>'9'))evt.consume();
    }//GEN-LAST:event_txt_passKeyTyped

    private void btn_imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_imprimirActionPerformed
        //Evento imprimir
        //Imprimir();
        Imprimir2();
    }//GEN-LAST:event_btn_imprimirActionPerformed

    private void Imprimir2(){
        //Map<String, String> parametros = Map.of("nombre1Pdf","ticket.pdf", "impresora", impresora, "serial", serial, "grados", grados);
        
        try {
            File path = new File("ticket.pdf");
            Desktop.getDesktop().open(path);
            
            //C:\Users\HP\Documents\NetBeansProjects
        } catch (IOException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void Imprimir() {
        PrinterMatrix printer = new PrinterMatrix();
        
        String archivo ="src/Imagenes/ticket.png";
        
        Extenso e= new Extenso();
        e.setNumber(101.85);
        
        printer.setOutSize(9,32);
        //printer.mapearDocumentoImageFile(1, 1, archivo);
        printer.mapearDocumento(1, 1, archivo);
        printer.toFile("ticket.txt");
        
        FileInputStream inputStream = null;
        
        try {
            inputStream = new FileInputStream("ticket.pdf");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        
        if (inputStream == null) {
            return;
        }
        
        DocFlavor docFormat = DocFlavor.INPUT_STREAM.AUTOSENSE;
        Doc document = new SimpleDoc(inputStream, docFormat, null);
        
        
        PrintRequestAttributeSet attributeSet = new HashPrintRequestAttributeSet();
        PrintService defaultPrintService = PrintServiceLookup.lookupDefaultPrintService();
        
        if (defaultPrintService != null) {
            DocPrintJob printJob = defaultPrintService.createPrintJob();
            try {
                printJob.print(document, attributeSet);
            } catch (Exception ex) {
                System.out.println("Error: "+ ex.toString());
            }
        }else{
            JOptionPane.showMessageDialog(null, "No hay una impresora instalada");
        }
    }
    
    private void PDF() {
        int resultado = 0;
        String usuario = txt_usuario.getText();
        String pass = String.valueOf(txt_pass.getPassword());
        String puerta = txt_puerta.getText();
        String sql = "SELECT * FROM usuarios WHERE nombre='" + usuario + "' AND puerta='" + puerta + "' AND pass ='" + pass + "'";

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                resultado = 1;
                if (resultado == 1) {
                    //CREAR QR
                    String codigo = ("USUARIO: "+usuario + " | PUERTA: " + puerta + " | HORA: " + horacompleta + " | FECHA: " + fechacompleta).trim();
                    //Tamaño del QR
                    int size = 100;
                    String FileType = "png";
                    
                    //CREAR nombre

                    // Ruta de la imagen
                    String filePath = "src/Imagenes/";
                    //JFileChooser chooser = new JFileChooser();
                    //chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    //if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                    //    filePath = chooser.getSelectedFile().getAbsolutePath();
                    //}

                    try {
                        //GENERAR EL QR
                        QRCodeWriter qrcode = new QRCodeWriter();
                        BitMatrix matrix = qrcode.encode(codigo, BarcodeFormat.QR_CODE, size, size);
                        File f = new File(filePath + "/ticket." + FileType);
                        int matrixWidth = matrix.getWidth();
                        BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_INT_RGB);
                        image.createGraphics();

                        Graphics2D graphics2D = (Graphics2D) image.getGraphics();
                        graphics2D.setColor(Color.white);//color del fondo
                        graphics2D.fillRect(0, 0, matrixWidth, matrixWidth);
                        graphics2D.setColor(Color.black);//color QR

                        //GENERAR IMAGEN
                        for (int b = 0; b < matrixWidth; b++) {
                            for (int j = 0; j < matrixWidth; j++) {
                                if (matrix.get(b, j)) {
                                    graphics2D.fillRect(b, j, 1, 1);
                                }
                            }
                        }

                        //Mostrar imagen del QR
                        ImageIO.write(image, FileType, f);
                        java.awt.Image mImagen = new ImageIcon(filePath + "/ticket." + FileType).getImage();

                    } catch (WriterException ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //Mandar a llamar la imagen de la empresa
                    Image header = Image.getInstance("src/Imagenes/agros.png");
                    Image header2 = Image.getInstance("src/Imagenes/ticket.png");
                    header.scaleToFit(50, 50);
                    //Crear PDF
                    FileOutputStream archivo = new FileOutputStream("ticket.pdf");
                    Document documento = new Document();
                    PdfWriter.getInstance(documento, archivo);
                    documento.open();

                    Paragraph parrafo = new Paragraph("PRESTAMO DE EQUIPOS INFORMÁTICOS");
                    documento.add(parrafo);
                    documento.add(header);
                    documento.add(new Paragraph("USUARIO: " + usuario));
                    documento.add(new Paragraph("PUERTA: " + puerta));
                    documento.add(new Paragraph("FECHA: " + fechacompleta));
                    documento.add(new Paragraph("HORA: " + horacompleta));
                    documento.add(header2);
                    documento.close();

                    //File path = new File("ticket.pdf");
                    //Desktop.getDesktop().open(path);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "NO EXISTE EL USUARIO");
        }

    }

    private void ValidarUsuario() {
        int resultado = 0;
        String usuario = txt_usuario.getText();
        String pass = String.valueOf(txt_pass.getPassword());
        String puerta = txt_puerta.getText();
        File archivo;
        FileWriter escribir;
        PrintWriter linea;
        archivo = new File("Registros" + fechacompleta + ".txt");

        int p = Integer.valueOf(puerta);

        String sql = "SELECT * FROM usuarios WHERE nombre='" + usuario + "' AND puerta='" + puerta + "' AND pass ='" + pass + "'";

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                resultado = 1;
                if (resultado == 1 && p == 0) {
                    Menu cu = new Menu();
                    cu.setVisible(true);
                    try {
                        registros.addRow(new Object[]{
                            usuario, fechacompleta, horacompleta
                        });

                        if (!archivo.exists()) {
                            try {
                                archivo.createNewFile();
                                escribir = new FileWriter(archivo, true);
                                linea = new PrintWriter(escribir);
                                linea.print(usuario + "|");
                                linea.print(fechacompleta + "|");
                                linea.println(horacompleta);
                                linea.close();
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Error al crear el Registros.txt");
                            }
                        } else {
                            try {
                                escribir = new FileWriter(archivo, true);
                                linea = new PrintWriter(escribir);
                                linea.print(usuario + "|");
                                linea.print(fechacompleta + "|");
                                linea.println(horacompleta);
                                linea.close();
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Error al crear el Registros.txt");
                            }
                        }
                    } catch (Exception e) {
                    }
                    this.dispose();
                } else {
                    try {
                        Arduino.sendData(puerta);

                        try {
                            registros.addRow(new Object[]{
                                usuario, fechacompleta, horacompleta
                            });

                            if (!archivo.exists()) {
                                try {

                                    //Crear archivo txt
                                    archivo.createNewFile();
                                    escribir = new FileWriter(archivo, true);
                                    linea = new PrintWriter(escribir);
                                    linea.print(usuario + "|");
                                    linea.print(fechacompleta + "|");
                                    linea.println(horacompleta);
                                    linea.close();

                                } catch (Exception e) {
                                    JOptionPane.showMessageDialog(null, "Error al crear el Registros.txt");
                                }
                            } else {
                                try {

                                    //Reescripción del archivo de registros
                                    escribir = new FileWriter(archivo, true);
                                    linea = new PrintWriter(escribir);
                                    linea.print(usuario + "|");
                                    linea.print(fechacompleta + "|");
                                    linea.println(horacompleta);
                                    linea.close();
                                } catch (Exception e) {
                                    JOptionPane.showMessageDialog(null, "Error al crear el Registros.txt");
                                }
                            }
                        } catch (Exception e) {
                        }
                        System.out.println("Se tuvo acceso a la puerta " + puerta + "\n");
                    } catch (Exception ex) {
                        Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    this.txt_usuario.setText("");
                    this.txt_pass.setText("");
                    this.txt_puerta.setText("");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Datos incorrectos");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al encontrar al usuario " + e.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_imprimir;
    private javax.swing.JButton btn_iniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lb_logo;
    private javax.swing.JTable tabla_registros;
    private javax.swing.JTextField txt_columnas;
    private javax.swing.JTextField txt_lineas;
    private javax.swing.JPasswordField txt_pass;
    private javax.swing.JTextField txt_puerta;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables


}
