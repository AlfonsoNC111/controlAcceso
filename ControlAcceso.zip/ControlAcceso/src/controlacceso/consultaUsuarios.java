package controlacceso;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class consultaUsuarios extends javax.swing.JFrame {
    //VARIABLES UNIVERSALES
    Connection con = null;
    Statement stmt = null;
    String titulos[] = {"id","Nombre","Puerta","Puesto","Contraseña","Tipo usuario","Modelo del Dispositivo","Marca del Dispositivo","Número de Serie del Dispositivo"};
    String fila[] = new String [9];
    DefaultTableModel modelo;
    String var, var2;
    
    public consultaUsuarios() {
        initComponents();
        //CONFIGURACIONES DE LA VENTANA
        this.setTitle("Consultar Usuarios");
        this.setLocation(300,200);
        this.setResizable(false);
        ImageIcon icono = new ImageIcon("C:\\Users\\HP\\Documents\\NetBeansProjects\\pruebaLeds\\src\\Imagenes\\agros.png");
        this.setIconImage(icono.getImage());
        
        try {
            //CONEXIÓN CON LA BASE DE DATOS
            String url = "jdbc:mysql://localhost:3306/controlacceso";//NOMBRE DE LA BASE DE DATOS
            String usuario = "root";//USUARIO DE MYSQL
            String contraseña = "123root";//CONTRASEÑA DE MYSQL
                //CLASE PARA EL ENVIO DE DATOS
               Class.forName("com.mysql.jdbc.Driver").newInstance();
               con = DriverManager.getConnection(url,usuario,contraseña);
               if (con!= null)
                   //MENSAJE DE VALIDACIÓN EN CONSOLA
                   System.out.println("Se ha establecido una conexion a la base de datos"+"\n"+url);
               
               stmt = con.createStatement();
               //CONSULTA PARA LA BASE DE DATOS
               ResultSet rs = stmt.executeQuery("select* from usuarios");
               //VARIABLE DE LOS TITULOS DE LA TABLA
               modelo = new DefaultTableModel(null,titulos);
               //CICLO DE BUSQUEDA DE DATOS
               while(rs.next()) {
                   
                   fila[0] = rs.getString("id");
                   fila[1] = rs.getString("nombre");
                   fila[2] = rs.getString("puerta");
                   fila[3] = rs.getString("puesto");
                   fila[4] = rs.getString("pass");
                   fila[5] = rs.getString("tipousuario");
                   fila[6] = rs.getString("modelo");
                   fila[7] = rs.getString("marca");
                   fila[8] = rs.getString("serie");
                   //CREACION DE LAS FILAS DE LA TABLA
                   modelo.addRow(fila);     
               }
               tabla_usuarios.setModel(modelo);
               //TITULOS DE LA TABLA
                TableColumn ci = tabla_usuarios.getColumn("id");
                ci.setMaxWidth(25);
                TableColumn cn = tabla_usuarios.getColumn("Nombre");
                cn.setMaxWidth(170);
                TableColumn cd = tabla_usuarios.getColumn("Puerta");
                cd.setMaxWidth(50);
                TableColumn ct = tabla_usuarios.getColumn("Puesto");
                ct.setMaxWidth(150);
                TableColumn cnick = tabla_usuarios.getColumn("Contraseña");
                cnick.setMaxWidth(90);
                TableColumn ctipo = tabla_usuarios.getColumn("Tipo usuario");
                ctipo.setMaxWidth(95);
                TableColumn cmodelo = tabla_usuarios.getColumn("Modelo del Dispositivo");
                cmodelo.setMaxWidth(500);
                TableColumn cmarca = tabla_usuarios.getColumn("Marca del Dispositivo");
                cmarca.setMaxWidth(500);
                TableColumn cnumSerie = tabla_usuarios.getColumn("Número de Serie del Dispositivo");
                cnumSerie.setMaxWidth(500);
               
        }
        catch (Exception e) {
            //MENSAJE DE ERROR CUANDO NO SE PUEDEN RECUPERAR LOS DATOS DE LA BD
            JOptionPane.showMessageDialog(null,"Error al extraer los datos de la tabla");
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_eliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_usuarios = new javax.swing.JTable();
        barraMenu = new javax.swing.JMenuBar();
        menuArchivo = new javax.swing.JMenu();
        menuRegistro = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_eliminar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btn_eliminar.setText("ELIMINAR USUARIO");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, -1, -1));

        tabla_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla_usuarios);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 340));

        menuArchivo.setText("Menú");

        menuRegistro.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_MASK));
        menuRegistro.setText("Ventana de Registro");
        menuRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRegistroActionPerformed(evt);
            }
        });
        menuArchivo.add(menuRegistro);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem1.setText("Menú Principal");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        menuArchivo.add(jMenuItem1);

        barraMenu.add(menuArchivo);

        setJMenuBar(barraMenu);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //METODO ELIMINAR REGISTRO
    public void eliminar(){
        try {
            //VARAIBLE DE SELECCIÓN EN LA TABLA
            int filaSeleccionada = tabla_usuarios.getSelectedRow();
            //CONSULTA PARA LA BASE DE DATOS
            String sql="DELETE FROM usuarios WHERE id="+tabla_usuarios.getValueAt(filaSeleccionada, 0);
            Statement st= con.createStatement();
            int n=st.executeUpdate(sql);
            //CONDICION DE ELIMINACIÓN DE REGISTRO
            if (n>=0) {
                //MENSAJE DE CONFIRMACIÓN PARA EL USUARIO
                JOptionPane.showMessageDialog(null, "Usuario eliminado satisfactoriamente");
            }
        } catch (Exception e) {
            //MENSAJE DE ERROR AL ELIMINAR EL REGISTRO
            JOptionPane.showMessageDialog(null, "Error al eliminar al Usuario");
        }
    }
    
        //METODO ACTUALIZAR
    public void actualizar() {
        try {
            //CONEXIÓN CON LA BASE DE DATOS
            String url = "jdbc:mysql://localhost:3306/controlacceso";//NOMBRE DE LA BASE DE DATOS
            String usuario = "root"; //USUARIO DE MYSQL
            String contraseña = "123root";  //CONTRASEÑA DE MYSQL
               //CLASE DE ENVIO DE DATOS
               Class.forName("com.mysql.jdbc.Driver").newInstance();
               con = DriverManager.getConnection(url,usuario,contraseña);
               if (con!= null)
                   //MENSAJE DE VALIDACIÓN CON LA BASE DE DATOS
                   System.out.println("Se ha establecido una conexion a la base de datos"+"\n"+url);
               stmt = con.createStatement();
               //CONSULTA PARA LA BD
               ResultSet rs = stmt.executeQuery("select* from usuarios");
               //CREACION DE TITULOS DE LA BD
               modelo = new DefaultTableModel(null,titulos);
               //CICLO DE BUSQUEDA DE DATOS
               while(rs.next()) {
                   //GUARDAR DATOS DE DE FILAS DE LA BD
                   fila[0] = rs.getString("id");
                   fila[1] = rs.getString("nombre");
                   fila[2] = rs.getString("puerta");
                   fila[3] = rs.getString("puesto");
                   fila[4] = rs.getString("pass");
                   fila[5] = rs.getString("tipousuario");
                   fila[6] = rs.getString("modelo");
                   fila[7] = rs.getString("marca");
                   fila[8] = rs.getString("serie");
                   //CREACION DE FILAS DE LA TABLA
                   modelo.addRow(fila);     
               }
               //ESPECIFICACIONES DE LA FILAS DE LA TABLA
               tabla_usuarios.setModel(modelo);
                TableColumn ci = tabla_usuarios.getColumn("id");
                ci.setMaxWidth(25);
                TableColumn cn = tabla_usuarios.getColumn("Nombre");
                cn.setMaxWidth(170);
                TableColumn cd = tabla_usuarios.getColumn("Puerta");
                cd.setMaxWidth(50);
                TableColumn ct = tabla_usuarios.getColumn("Puesto");
                ct.setMaxWidth(150);
                TableColumn cnick = tabla_usuarios.getColumn("Contraseña");
                cnick.setMaxWidth(90);
                TableColumn ctipo = tabla_usuarios.getColumn("Tipo usuario");
                ctipo.setMaxWidth(95);
                TableColumn cmodelo = tabla_usuarios.getColumn("Modelo del Dispositivo");
                cmodelo.setMaxWidth(1600);
                TableColumn cmarca = tabla_usuarios.getColumn("Marca del Dispositivo");
                cmarca.setMaxWidth(1600);
                TableColumn cnumSerie = tabla_usuarios.getColumn("Número de Serie del Dispositivo");
                cnumSerie.setMaxWidth(1600);
               
        }
        catch (Exception e) {
            //MENSAJE DE ERROR AL OBTENER LOS DATOS DE LA BD
            JOptionPane.showMessageDialog(null,"Error al extraer los datos de la tabla");
        }
    }
    
    private void menuRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRegistroActionPerformed
        // CAMBIO DE VENTANA A REGISTRO DE USUARIOS
        this.dispose();
        RegistrarUsuarios u = new RegistrarUsuarios();
        u.setVisible(true);
    }//GEN-LAST:event_menuRegistroActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // CAMBIO DE VENTANA A MENÚ PRINCIPAL DEL ADMINISTRADOR
        this.dispose();
        Menu cu = new Menu();
        cu.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        //LLAMAR A LOS METODOS DE ELIMINAR Y ACTUALIZAR
        eliminar();
        actualizar();
    }//GEN-LAST:event_btn_eliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(consultaUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(consultaUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(consultaUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(consultaUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new consultaUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar barraMenu;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuArchivo;
    private javax.swing.JMenuItem menuRegistro;
    private javax.swing.JTable tabla_usuarios;
    // End of variables declaration//GEN-END:variables
}
