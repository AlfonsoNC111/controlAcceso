package controlacceso;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConexionDB {
    Connection conectar = null;
    public Connection conexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/controlacceso";
            String usuario = "root";
            String contraseña = "123root";
             
            //VARIABLE DE CONEXION DE DATOS
            conectar =(Connection) DriverManager.getConnection(url,usuario,contraseña);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error de conexión con la base de datos" +e.getMessage());
        }
        return conectar;
        
    }
}
